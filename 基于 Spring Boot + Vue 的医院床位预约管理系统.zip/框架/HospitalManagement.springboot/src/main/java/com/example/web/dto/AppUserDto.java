package com.example.web.dto;

import java.lang.reflect.InvocationTargetException;
import java.time.LocalDate;

import org.apache.commons.beanutils.BeanUtils;

import com.example.web.entity.AppUser;
import com.example.web.enums.RoleTypeEnum;
import com.example.web.tools.dto.BaseDto;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class AppUserDto extends BaseDto {

    /**
     * 账号
     */
    @JsonProperty("UserName")
    private String UserName;
    /**
     * 密码
     */
    @JsonProperty("Password")
    private String Password;
    /**
     * 原始密码
     */
    @JsonProperty("OrginPassword")
    private String OrginPassword;

    /**
     * 邮箱
     */
    @JsonProperty("Email")
    private String Email;
    /**
     * 头像
     */
    @JsonProperty("ImageUrls")
    private String ImageUrls;
    /**
     * 名称
     */
    @JsonProperty("Name")
    private String Name;
    /**
     * 手机号码
     */
    @JsonProperty("PhoneNumber")
    private String PhoneNumber;
    /**
     * 出生年月（仅日期）
     */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @JsonProperty("Birth")
    private LocalDate Birth;
    /**
     * 账号角色
     */
    @JsonProperty("RoleType")
    private Integer RoleType;

    @JsonProperty("RoleTypeFormat")
    public String RoleTypeFormat() {
        return RoleTypeEnum.GetEnum(RoleType).toString();
    };

    /**
     * 把账号传输模型转换成账号实体
     */
    public AppUser MapToEntity() throws InvocationTargetException, IllegalAccessException {
        AppUser AppUser = new AppUser();
        BeanUtils.copyProperties(AppUser, this);
        return AppUser;
    }

}
